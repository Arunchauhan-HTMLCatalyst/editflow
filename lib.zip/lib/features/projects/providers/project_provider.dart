import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/project.dart';
import '../models/project_status.dart';
import '../repositories/project_repository.dart';
import '../../../services/supabase_service.dart';
import '../../../shared/services/activity_service.dart';

class ProjectProvider extends AsyncNotifier<List<Project>> {
  StreamSubscription<List<Map<String, dynamic>>>? _subscription;

  List<Project> _sort(List<Project> projects) {
    return List.from(projects)..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  @override
  Future<List<Project>> build() async {
    final repo = ref.watch(projectRepositoryProvider);
    final uid = SupabaseService.userId;

    print('[ProjectProvider] build() initialized, user=$uid');

    _subscription?.cancel();
    _subscription = SupabaseService.instance
        .from('projects')
        .stream(primaryKey: ['id'])
        .eq('user_id', uid)
        .listen(
      (rows) {
        print('[ProjectProvider] stream received ${rows.length} rows');
        final projects = <Project>[];
        for (final e in rows) {
          final p = Project.tryFromJson(e);
          if (p != null) {
            projects.add(p);
          } else {
            print('[ProjectProvider] skipped invalid row: $e');
          }
        }
        final sorted = _sort(projects);
        print('[ProjectProvider] stream parsed ${sorted.length} valid projects');
        state = AsyncData(sorted);
      },
      onError: (e) {
        print('[ProjectProvider] stream error: $e');
        if (state is! AsyncData) {
          state = AsyncData([]);
        }
      },
    );
    ref.onDispose(() {
      print('[ProjectProvider] disposed');
      _subscription?.cancel();
    });

    try {
      final fetched = await repo.getAll();
      print('[ProjectProvider] initial fetch returned ${fetched.length} projects');
      return fetched;
    } catch (e, st) {
      print('[ProjectProvider] initial fetch failed: $e');
      state = AsyncError(e, st);
      return [];
    }
  }

  Future<void> addProject(Project project) async {
    final repo = ref.read(projectRepositoryProvider);
    final previousState = state.valueOrNull ?? [];
    final tempProject = project.copyWith(id: '_temp_${DateTime.now().millisecondsSinceEpoch}');

    state = AsyncData([tempProject, ...previousState]);

    try {
      final newProject = await repo.create(project);
      final current = state.valueOrNull ?? [];
      state = AsyncData(_sort([
        newProject,
        ...current.where((p) => p.id != tempProject.id && p.id != newProject.id),
      ]));
      print('[ProjectProvider] addProject: created ${newProject.id}');
    } catch (e, st) {
      print('[ProjectProvider] addProject failed: $e');
      state = AsyncData(previousState);
      state = AsyncError(e, st);
      rethrow;
    }
  }

  Future<void> updateProject(Project project) async {
    final repo = ref.read(projectRepositoryProvider);
    final previousState = state.valueOrNull ?? [];

    final optimistic = previousState.map((p) => p.id == project.id ? project : p).toList();
    state = AsyncData(optimistic);

    try {
      final updated = await repo.update(project);
      final current = state.valueOrNull ?? [];
      state = AsyncData(current.map((p) => p.id == updated.id ? updated : p).toList());
      print('[ProjectProvider] updateProject: updated ${updated.id}');
    } catch (e, st) {
      print('[ProjectProvider] updateProject failed: $e');
      state = AsyncData(previousState);
      state = AsyncError(e, st);
      rethrow;
    }
  }

  Future<void> deleteProject(String id) async {
    final repo = ref.read(projectRepositoryProvider);
    final previousState = state.valueOrNull ?? [];
    final projectName = previousState.where((p) => p.id == id).firstOrNull?.name ?? '';

    state = AsyncData(previousState.where((p) => p.id != id).toList());

    try {
      await repo.delete(id);
      final activity = ActivityService();
      unawaited(activity.log(
        type: 'project_deleted',
        description: 'Deleted project "$projectName"',
        referenceId: id,
        referenceType: 'project',
      ));
      print('[ProjectProvider] deleteProject: deleted $id');
    } catch (e, st) {
      print('[ProjectProvider] deleteProject failed: $e');
      state = AsyncData(previousState);
      state = AsyncError(e, st);
    }
  }

  Future<void> updateStatus(String id, ProjectStatus newStatus) async {
    final projects = state.valueOrNull ?? [];
    final project = projects.firstWhereOrNull((p) => p.id == id);
    if (project == null) return;

    Project updated;
    if (newStatus == ProjectStatus.paid) {
      updated = project.copyWith(status: newStatus, receivedAmount: project.price);
    } else if (project.status == ProjectStatus.paid) {
      updated = project.copyWith(status: newStatus, receivedAmount: 0);
    } else {
      updated = project.copyWith(status: newStatus);
    }

    final repo = ref.read(projectRepositoryProvider);
    final previousState = state.valueOrNull ?? [];
    state = AsyncData(projects.map((p) => p.id == id ? updated : p).toList());

    try {
      final confirmed = await repo.update(updated);
      final current = state.valueOrNull ?? [];
      state = AsyncData(current.map((p) => p.id == confirmed.id ? confirmed : p).toList());
      print('[ProjectProvider] updateStatus: $id -> ${newStatus.displayName}');

      final activityType = newStatus == ProjectStatus.paid ? 'payment_received' : 'status_changed';
      await repo.logStatusChange(
        type: activityType,
        description: newStatus == ProjectStatus.paid
            ? 'Payment completed for "${project.name}"'
            : '"${project.name}" -> ${newStatus.displayName}',
        projectId: project.id,
      );
    } catch (e, st) {
      print('[ProjectProvider] updateStatus failed: $e');
      state = AsyncData(previousState);
      state = AsyncError(e, st);
    }
  }

  Future<void> refresh() async {
    final repo = ref.read(projectRepositoryProvider);
    final previousState = state.valueOrNull ?? [];
    print('[ProjectProvider] refresh() called');
    try {
      final projects = await repo.getAll();
      print('[ProjectProvider] refresh: got ${projects.length} projects');
      if (projects.isNotEmpty || previousState.isEmpty) {
        state = AsyncData(projects);
      }
    } catch (e, st) {
      print('[ProjectProvider] refresh failed: $e');
      if (previousState.isNotEmpty) {
        state = AsyncData(previousState);
      } else {
        state = AsyncError(e, st);
      }
    }
  }
}

extension _FirstWhereOrNull<T> on List<T> {
  T? firstWhereOrNull(bool Function(T) test) {
    for (final element in this) {
      if (test(element)) return element;
    }
    return null;
  }
}

final projectRepositoryProvider = Provider<ProjectRepository>((ref) => ProjectRepository());

final projectProvider = AsyncNotifierProvider<ProjectProvider, List<Project>>(
  () => ProjectProvider(),
);
