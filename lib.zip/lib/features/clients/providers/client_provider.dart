import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/client.dart';
import '../repositories/client_repository.dart';
import '../../../services/supabase_service.dart';

class ClientProvider extends AsyncNotifier<List<Client>> {
  StreamSubscription<List<Map<String, dynamic>>>? _subscription;

  @override
  Future<List<Client>> build() async {
    final repo = ref.watch(clientRepositoryProvider);
    final uid = SupabaseService.userId;

    print('[ClientProvider] build() initialized, user=$uid');

    _subscription?.cancel();
    _subscription = SupabaseService.instance
        .from('clients')
        .stream(primaryKey: ['id'])
        .eq('user_id', uid)
        .listen(
      (rows) {
        print('[ClientProvider] stream received ${rows.length} rows');
        final clients = <Client>[];
        for (final e in rows) {
          final c = Client.tryFromJson(e);
          if (c != null) {
            clients.add(c);
          } else {
            print('[ClientProvider] skipped invalid row: $e');
          }
        }
        print('[ClientProvider] stream parsed ${clients.length} valid clients');
        state = AsyncData(clients);
      },
      onError: (e) {
        print('[ClientProvider] stream error: $e');
        if (state is! AsyncData) {
          state = AsyncData([]);
        }
      },
    );
    ref.onDispose(() {
      print('[ClientProvider] disposed');
      _subscription?.cancel();
    });

    try {
      final fetched = await repo.getAll();
      print('[ClientProvider] initial fetch returned ${fetched.length} clients');
      return fetched;
    } catch (e, st) {
      print('[ClientProvider] initial fetch failed: $e');
      state = AsyncError(e, st);
      return [];
    }
  }

  Future<void> addClient(Client client) async {
    final repo = ref.read(clientRepositoryProvider);
    final previousState = state.valueOrNull ?? [];
    final tempClient = client.copyWith(id: '_temp_${DateTime.now().millisecondsSinceEpoch}');

    state = AsyncData([tempClient, ...previousState]);

    try {
      final newClient = await repo.create(client);
      final current = state.valueOrNull ?? [];
      state = AsyncData([
        newClient,
        ...current.where((c) => c.id != tempClient.id && c.id != newClient.id),
      ]);
      print('[ClientProvider] addClient: created ${newClient.id}');
    } catch (e, st) {
      print('[ClientProvider] addClient failed: $e');
      state = AsyncData(previousState);
      state = AsyncError(e, st);
    }
  }

  Future<void> updateClient(Client client) async {
    final repo = ref.read(clientRepositoryProvider);
    final previousState = state.valueOrNull ?? [];

    final optimistic = previousState.map((c) => c.id == client.id ? client : c).toList();
    state = AsyncData(optimistic);

    try {
      final updated = await repo.update(client);
      final current = state.valueOrNull ?? [];
      state = AsyncData(current.map((c) => c.id == updated.id ? updated : c).toList());
      print('[ClientProvider] updateClient: updated ${updated.id}');
    } catch (e, st) {
      print('[ClientProvider] updateClient failed: $e');
      state = AsyncData(previousState);
      state = AsyncError(e, st);
    }
  }

  Future<void> deleteClient(String id) async {
    final repo = ref.read(clientRepositoryProvider);
    final previousState = state.valueOrNull ?? [];

    state = AsyncData(previousState.where((c) => c.id != id).toList());

    try {
      await repo.delete(id);
      print('[ClientProvider] deleteClient: deleted $id');
    } catch (e, st) {
      print('[ClientProvider] deleteClient failed: $e');
      state = AsyncData(previousState);
      state = AsyncError(e, st);
    }
  }

  Future<void> refresh() async {
    final repo = ref.read(clientRepositoryProvider);
    final previousState = state.valueOrNull ?? [];
    print('[ClientProvider] refresh() called');
    try {
      final clients = await repo.getAll();
      print('[ClientProvider] refresh: got ${clients.length} clients');
      if (clients.isNotEmpty || previousState.isEmpty) {
        state = AsyncData(clients);
      }
    } catch (e, st) {
      print('[ClientProvider] refresh failed: $e');
      if (previousState.isNotEmpty) {
        state = AsyncData(previousState);
      } else {
        state = AsyncError(e, st);
      }
    }
  }
}

final clientRepositoryProvider = Provider<ClientRepository>((ref) => ClientRepository());

final clientProvider = AsyncNotifierProvider<ClientProvider, List<Client>>(
  () => ClientProvider(),
);
